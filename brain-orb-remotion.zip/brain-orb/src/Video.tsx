import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {FPS, SCRIPTS, ScriptId, USE_AUDIO, sceneFrames} from './scripts';
import {SceneView} from './Scenes';

export const Video: React.FC<{script: ScriptId}> = ({script}) => {
  const s = SCRIPTS[script];
  let from = 0;
  return (
    <AbsoluteFill style={{background: '#04060f'}}>
      {USE_AUDIO && <Audio src={staticFile(`music/${s.music}`)} volume={0.22} loop />}
      {s.scenes.map((sc, i) => {
        const d = sceneFrames(sc);
        const start = from;
        from += d;
        return (
          <Sequence key={i} from={start} durationInFrames={d}>
            <SceneView def={sc} />
            {USE_AUDIO && <Audio src={staticFile(`voice/${script}-${i + 1}.mp3`)} />}
            {USE_AUDIO && sc.sfx.map((x, k) => (
              <Sequence key={k} from={Math.round(x.t * FPS)}>
                <Audio src={staticFile(`sfx/${x.cue}.mp3`)} volume={0.6} />
              </Sequence>
            ))}
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};

import data from './scripts.json';

export type Kind = 'hook' | 'absorb' | 'predict' | 'slowtime' | 'overload' | 'limit' | 'ending';
export type SceneDef = {
  kind: Kind; dur: number; level: number; topic: string;
  lines: string[]; sfx: {t: number; cue: string}[]; visual: string;
};
export type ScriptDef = {id: string; title: string; music: string; scenes: SceneDef[]};
export type ScriptId = 'short' | 'long';

export const SCRIPTS = data as unknown as Record<ScriptId, ScriptDef>;
export const FPS = 30;
export const QUESTION = 'Would more processing power make you smarter\u2014or just overwhelm you?';

/** Flip to true after you add files to public/voice, public/sfx, public/music (see README). */
export const USE_AUDIO = false;

export const sceneFrames = (s: SceneDef) => Math.round(s.dur * FPS);
export const totalFrames = (id: ScriptId) =>
  SCRIPTS[id].scenes.reduce((a, s) => a + sceneFrames(s), 0);

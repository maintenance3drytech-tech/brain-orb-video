import React from 'react';
import {AbsoluteFill, interpolate, random, useCurrentFrame, useVideoConfig} from 'remotion';
import {Backdrop, SYMBOLS} from './Backdrop';
import {Orb, Mood} from './Orb';
import {QUESTION, SceneDef} from './scripts';

const TAU = Math.PI * 2;
const C = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const mod = (a: number, b: number) => ((a % b) + b) % b;
const sym = (k: string) => SYMBOLS[Math.floor(random(k) * SYMBOLS.length)];
const poly = (cx: number, cy: number, r: number, n: number, rot: number) =>
  Array.from({length: n}, (_, i) => `${cx + r * Math.cos(rot + (i * TAU) / n)},${cy + r * Math.sin(rot + (i * TAU) / n)}`).join(' ');

type P = {def: SceneDef};
const useGeo = () => {
  const {width: w, height: h, durationInFrames: D} = useVideoConfig();
  return {w, h, D, u: Math.min(w, h), cx: w / 2, cy: h * 0.42, wide: w > h};
};
const Glyph: React.FC<{x: number; y: number; s: number; o: number; t: string; rot?: number; c?: string}> =
  ({x, y, s, o, t, rot = 0, c = '#8fd3ff'}) => (
    <text x={x} y={y} fontSize={Math.max(1, s)} fill={c} opacity={o} textAnchor="middle"
      dominantBaseline="central" transform={`rotate(${rot} ${x} ${y})`} fontFamily="Georgia, serif">{t}</text>
  );
const SvgFull: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  return <svg width={width} height={height}>{children}</svg>;
};
const Banner: React.FC<{text: string; color?: string; y?: number}> = ({text, color = '#7fd0ff', y = 0.06}) => {
  const {h, u} = useGeo();
  return <div style={{position: 'absolute', top: h * y, left: '6%', right: '6%', textAlign: 'center', color,
    letterSpacing: u * 0.005, fontSize: u * 0.03, fontFamily: 'system-ui,sans-serif', fontWeight: 700}}>{text}</div>;
};

/* ---------- SCENE 1: THE HOOK ---------- */
const Hook: React.FC<P> = () => {
  const f = useCurrentFrame();
  const {w, D, u, cx, cy, wide} = useGeo();
  const N = 260, start = D * 0.2, step = (D * 0.7) / N;
  const n = Math.min(N, Math.max(0, Math.floor((f - start) / step)));
  return (
    <AbsoluteFill><Backdrop count={14} />
      <SvgFull>
        {Array.from({length: n}, (_, i) => {
          const a = random(`a${i}`) * TAU, d = u * (0.18 + random(`d${i}`) * 0.75);
          const pop = interpolate(f - (start + i * step), [0, 8], [0, 1], C);
          return <Glyph key={i} t={sym(`s${i}`)} x={cx + Math.cos(a) * d * (wide ? 1.6 : 0.6)} y={cy + Math.sin(a) * d}
            s={u * (0.03 + random(`z${i}`) * 0.05) * pop} o={(0.3 + random(`o${i}`) * 0.7) * pop} rot={f * (random(`r${i}`) - 0.5) * 3} />;
        })}
        <Orb x={cx} y={cy} size={u * 0.22} glow={interpolate(f, [0, D], [0.4, 1.2])}
          mood={f > D * 0.55 ? 'shocked' : 'curious'} look={[Math.sin(f / 30), Math.cos(f / 40) * 0.5]} />
      </SvgFull>
    </AbsoluteFill>
  );
};

/* ---------- SCENE 2: RAPID LEARNING ---------- */
const Absorb: React.FC<P> = ({def}) => {
  const f = useCurrentFrame();
  const {w, h, D, u, cx, cy} = useGeo();
  const N = 50 + def.level * 45, gap = (D * 0.85) / N, life = 26;
  const done = Math.min(N, Math.max(0, Math.floor((f - life) / gap)));
  const prog = done / N;
  return (
    <AbsoluteFill><Backdrop count={10} speed={1.5} />
      <SvgFull>
        {Array.from({length: N}, (_, i) => {
          const p = (f - i * gap) / life;
          if (p < 0 || p >= 1) return null;
          const e = p * p, ang = random(`aa${i}`) * TAU + (1 - e) * 1.4, rad = Math.hypot(w, h) * 0.55 * (1 - e);
          return <Glyph key={i} t={sym(`as${i}`)} x={cx + Math.cos(ang) * rad} y={cy + Math.sin(ang) * rad}
            s={u * 0.055 * (1 - e * 0.6)} o={0.4 + 0.6 * e} rot={p * 360} c={i % 3 ? '#8fd3ff' : '#b9f0ff'} />;
        })}
        <Orb x={cx} y={cy} size={u * 0.2 * (1 + prog * 0.4)} glow={0.5 + prog * 1.1}
          mood={prog > 0.8 ? 'happy' : 'focused'} look={[Math.sin(f / 10), Math.cos(f / 13)]} spin={1 + prog * 2} />
      </SvgFull>
    </AbsoluteFill>
  );
};

/* ---------- SCENE 3: PREDICTING PATTERNS ---------- */
const Predict: React.FC<P> = ({def}) => {
  const f = useCurrentFrame();
  const {w, h, u, cx, cy, wide} = useGeo();
  const N = 3 + def.level * 2;
  const pos = (i: number, t: number): [number, number] => {
    const A = w * (wide ? 0.38 : 0.4) * (0.55 + 0.45 * random(`pa${i}`));
    const B = u * (0.2 + 0.25 * random(`pb${i}`)) * (wide ? 1 : 1.5);
    const wx = 0.018 + random(`wx${i}`) * 0.02, wy = 0.014 + random(`wy${i}`) * 0.02;
    return [cx + A * Math.cos(wx * t + i * 1.7), cy + B * Math.sin(wy * t + i * 2.3)];
  };
  const focus = Math.floor(f / 45) % N;
  const [gx, gy] = pos(focus, f + 60);
  const d = Math.hypot(gx - cx, gy - cy) || 1;
  return (
    <AbsoluteFill><Backdrop count={12} />
      <SvgFull>
        {Array.from({length: N}, (_, i) => {
          const [x, y] = pos(i, f), [fx, fy] = pos(i, f + 60);
          const path = Array.from({length: 21}, (_, k) => pos(i, f + k * 3).join(',')).join(' ');
          const sides = 3 + (i % 3), hue = 190 + i * 25;
          return (
            <g key={i}>
              <polyline points={path} fill="none" stroke="#5cf" strokeWidth={u * 0.004} strokeDasharray={`${u * 0.01} ${u * 0.012}`} opacity={0.45} />
              <polygon points={poly(fx, fy, u * 0.035, sides, 0)} fill="none" stroke="#5cf" strokeWidth={u * 0.004} opacity={0.5} />
              <polygon points={poly(x, y, u * 0.04, sides, f * 0.04 * (i % 2 ? 1 : -1))} fill={`hsl(${hue} 90% 60%)`} opacity={0.9} />
            </g>
          );
        })}
        <Orb x={cx} y={cy} size={u * 0.2} glow={1} mood="focused" hue={185} look={[(gx - cx) / d, (gy - cy) / d]} />
      </SvgFull>
    </AbsoluteFill>
  );
};

/* ---------- SCENE 4: TIME FEELS DIFFERENT (fictional!) ---------- */
const SlowTime: React.FC<P> = () => {
  const f = useCurrentFrame();
  const {w, h, u, cx, cy} = useGeo();
  const clockX = w * 0.84, clockY = u * 0.2, cr = u * 0.08;
  const lit = Math.floor(f * 2);
  const orbR = u * 0.2;
  return (
    <AbsoluteFill><Backdrop count={40} speed={0.1} />
      <SvgFull>
        {Array.from({length: 6}, (_, i) => (
          <polygon key={i} points={poly(w * (0.1 + 0.8 * random(`sx${i}`)), mod(f * 0.6 + (i * h) / 6, h + 100) - 50, u * 0.04, 4, f * 0.004)}
            fill="none" stroke="#6a86b8" strokeWidth={u * 0.004} opacity={0.6} />
        ))}
        <circle cx={clockX} cy={clockY} r={cr} fill="none" stroke="#6a86b8" strokeWidth={u * 0.006} />
        <line x1={clockX} y1={clockY} x2={clockX + Math.sin((f * 0.35 * Math.PI) / 180) * cr * 0.8}
          y2={clockY - Math.cos((f * 0.35 * Math.PI) / 180) * cr * 0.8} stroke="#9ab" strokeWidth={u * 0.006} strokeLinecap="round" />
        <text x={clockX} y={clockY + cr * 1.5} fontSize={u * 0.02} fill="#6a86b8" textAnchor="middle" fontFamily="system-ui" fontWeight={700}>WORLD CLOCK</text>
        {Array.from({length: 48}, (_, i) => {
          const a = (i / 48) * TAU - Math.PI / 2, dist = mod(lit - i, 48), o = dist < 10 ? 1 - dist / 10 : 0.08;
          return <line key={i} x1={cx + Math.cos(a) * orbR * 1.7} y1={cy + Math.sin(a) * orbR * 1.7}
            x2={cx + Math.cos(a) * orbR * 1.95} y2={cy + Math.sin(a) * orbR * 1.95} stroke="#7fe3ff" strokeWidth={u * 0.008} opacity={o} />;
        })}
        {Array.from({length: 4}, (_, i) => (
          <text key={i} x={i % 2 ? cx + orbR * 2.3 : cx - orbR * 2.3} y={cy - orbR * 0.6 + i * u * 0.05} fontSize={u * 0.024}
            fill="#8fd3ff" opacity={0.7} textAnchor={i % 2 ? 'start' : 'end'} fontFamily="monospace">
            {`${Math.floor(random(`q${f}${i}`) * 9999)}\u00d7${Math.floor(random(`r${f}${i}`) * 999)}`}
          </text>
        ))}
        <Orb x={cx} y={cy} size={orbR * 2 * 0.9} glow={1} mood="focused" spin={4} look={[Math.cos(f / 6), Math.sin(f / 7)]} />
      </SvgFull>
      <div style={{opacity: interpolate(f, [0, 15], [0, 1], C)}}>
        <Banner text={"FICTIONAL VISUALIZATION \u00b7 TIME ITSELF HAS NOT SLOWED"} color="#ffd36b" />
      </div>
    </AbsoluteFill>
  );
};

/* ---------- SCENE 5: OVERLOAD ---------- */
const Overload: React.FC<P> = () => {
  const f = useCurrentFrame();
  const {w, h, D, u, cx, cy} = useGeo();
  const k = f / D, N = Math.floor(40 + k * k * 300);
  const amp = u * 0.03 + k * u * 0.09;
  return (
    <AbsoluteFill><Backdrop count={30} speed={4} />
      <SvgFull>
        {Array.from({length: N}, (_, i) => (
          <Glyph key={i} t={sym(`ov${i}`)} x={mod(random(`ox${i}`) * w + f * (random(`vx${i}`) - 0.5) * 40, w)}
            y={mod(random(`oy${i}`) * h + f * (random(`vy${i}`) - 0.5) * 40, h)} s={u * (0.02 + random(`oz${i}`) * 0.05)}
            o={0.3 + random(`oo${i}`) * 0.6} rot={f * 5 * random(`or${i}`)} c={`hsl(${210 - k * 200 + random(`oc${i}`) * 40} 100% 70%)`} />
        ))}
        {Array.from({length: 24}, (_, i) => (
          <polygon key={i} points={poly(mod(random(`px${i}`) * w + f * (10 + i * 2) * (i % 2 ? 1 : -1), w), random(`py${i}`) * h, u * 0.03, 3 + (i % 3), f * 0.2)}
            fill="none" stroke={`hsl(${20 + i * 12} 100% 65%)`} strokeWidth={u * 0.005} opacity={0.8} />
        ))}
        {[0, 1, 2].map((j) => {
          const pts = Array.from({length: Math.ceil(w / 16) + 1}, (_, s) => {
            const x = s * 16;
            return `${x},${h * (0.62 + 0.04 * j) + Math.sin(x * 0.02 * (j + 1) + f * 0.3 * (j + 1)) * amp * (0.6 + random(`wv${s}${f}`) * 0.6)}`;
          }).join(' ');
          return <polyline key={j} points={pts} fill="none" stroke={`hsl(${190 - k * 170 - j * 20} 100% 60%)`} strokeWidth={u * 0.006} opacity={0.8} />;
        })}
        <Orb x={cx} y={cy} size={u * 0.2} glow={(0.7 + random(`g${f}`) * 0.9) * (0.5 + k)} hue={210 - k * 200}
          mood={k < 0.35 ? 'shocked' : 'strained'} jitter={0.2 + k} spin={3} look={[random(`lk${f}`) - 0.5, random(`ll${f}`) - 0.5]} />
      </SvgFull>
      <AbsoluteFill style={{background: `radial-gradient(circle, transparent 40%, rgba(255,30,0,${k * 0.5}) 100%)`}} />
      <AbsoluteFill style={{background: '#fff', opacity: random(`fl${f}`) > 0.93 ? 0.22 * k : 0}} />
    </AbsoluteFill>
  );
};

/* ---------- SCENE 6: THE LIMIT ---------- */
const Limit: React.FC<P> = ({def}) => {
  const f = useCurrentFrame();
  const {w, h, D, u, cx} = useGeo();
  const topics = def.topic === 'all' ? ['memory', 'energy', 'knowledge'] : [def.topic];
  const seg = D / topics.length, idx = Math.min(topics.length - 1, Math.floor(f / seg)), lf = f - idx * seg;
  const tp = topics[idx], pw = Math.min(w * 0.82, u * 0.9), px = cx - pw / 2, py = h * 0.38;
  const frac = clampN(lf / seg);
  const mood: Mood = tp === 'energy' ? 'strained' : 'curious';
  const label = (t: string, y: number) => (
    <text x={cx} y={y} textAnchor="middle" fill="#cfe9ff" fontSize={u * 0.032} fontFamily="system-ui" fontWeight={700} letterSpacing={2}>{t}</text>);
  let panel: React.ReactNode = null;
  if (tp === 'memory') {
    const sw = pw / 4, sh = u * 0.16, sy = py + u * 0.12;
    panel = (<g>
      {[0, 1, 2, 3].map((k) => {
        const arr = 12 + k * (seg / 9), on = lf >= arr;
        return <rect key={k} x={px + k * sw + 6} y={sy} width={sw - 12} height={sh} rx={14} stroke="#4fb0ff" strokeWidth={3} fill={`hsla(200,100%,60%,${on ? 0.5 : 0.08})`} />;
      })}
      {Array.from({length: 8}, (_, j) => {
        const arr = 12 + j * (seg / 9), p = clampN((lf - (arr - 24)) / 24);
        if (lf < arr - 24) return null;
        const tx = px + Math.min(j, 3) * sw + sw / 2, ty = sy + sh / 2, y0 = py - u * 0.05;
        if (j < 4) return <Glyph key={j} t={sym(`m${j}`)} x={tx} y={lerp(y0, ty, p * p)} s={u * 0.07} o={1} c="#fff" />;
        const bt = Math.max(0, lf - arr);
        return <g key={j}><Glyph t={sym(`m${j}`)} x={tx + (j % 2 ? 1 : -1) * bt * 5} y={lerp(y0, ty, p * p) - bt * 3} s={u * 0.07} o={Math.max(0, 1 - bt / 20)} c="#ff8a7a" />
          {bt < 12 && <Glyph t={'\u00d7'} x={tx} y={ty} s={u * 0.12} o={1} c="#ff4d4d" />}</g>;
      })}
      {label('WORKING MEMORY \u2248 4 CHUNKS', sy + sh + u * 0.07)}
    </g>);
  } else if (tp === 'energy') {
    const fr = 1 - 0.82 * frac, bw = pw * 0.9, bh = u * 0.13, bx = cx - bw / 2, by = py + u * 0.12;
    panel = (<g>
      <rect x={bx} y={by} width={bw} height={bh} rx={14} fill="none" stroke="#cfe9ff" strokeWidth={4} />
      <rect x={bx + bw} y={by + bh * 0.3} width={u * 0.02} height={bh * 0.4} fill="#cfe9ff" />
      <rect x={bx + 6} y={by + 6} width={Math.max(0, (bw - 12) * fr)} height={bh - 12} rx={9} fill={`hsl(${fr * 120} 90% 55%)`} />
      {label('ENERGY BUDGET \u2248 20 WATTS', by + bh + u * 0.07)}
    </g>);
  } else {
    const cols = 5, rows = 3, tw = pw / cols, th = u * 0.1, known = [1, 6, 12], scan = mod(lf * 9, pw + 60);
    panel = (<g>
      {Array.from({length: cols * rows}, (_, k) => {
        const x = px + (k % cols) * tw + 5, y = py + u * 0.04 + Math.floor(k / cols) * (th + 8), isK = known.includes(k);
        const hit = scan > x - px - 30 && scan < x - px + tw;
        return <g key={k}><rect x={x} y={y} width={tw - 10} height={th} rx={10} stroke="#4fb0ff" strokeWidth={2}
          fill={isK ? 'hsla(160,100%,55%,0.55)' : `hsla(215,60%,30%,${hit ? 0.5 : 0.25})`} />
          {!isK && <Glyph t="?" x={x + (tw - 10) / 2} y={y + th / 2} s={th * 0.6} o={0.8} c="#9db8ff" />}</g>;
      })}
      <rect x={px + scan - 30} y={py} width={6} height={(th + 8) * rows + u * 0.06} fill="#7fe3ff" opacity={0.8} />
      {label('SPEED \u2260 FACTS YOU NEVER LEARNED', py + (th + 8) * rows + u * 0.12)}
    </g>);
  }
  return (
    <AbsoluteFill><Backdrop count={8} speed={0.5} />
      <SvgFull>
        <Orb x={cx} y={h * 0.2} size={u * 0.15} glow={tp === 'energy' ? 1.1 - frac * 0.7 : 0.8} mood={mood}
          jitter={tp === 'energy' ? frac * 0.3 : 0} look={[0, 0.6]} />
        {panel}
      </SvgFull>
    </AbsoluteFill>
  );
};
const clampN = (x: number) => Math.max(0, Math.min(1, x));

/* ---------- SCENE 7: THE ENDING ---------- */
const End: React.FC<P> = () => {
  const f = useCurrentFrame();
  const {w, h, D, u, cx} = useGeo();
  const N = 90, p = clampN(f / (D * 0.3)), ease = 1 - (1 - p) * (1 - p);
  const words = QUESTION.replace('\u2014', '\u2014 ').split(' ');
  return (
    <AbsoluteFill><Backdrop count={30} speed={0.4} />
      <SvgFull>
        {Array.from({length: N}, (_, i) => {
          const a = (i / N) * TAU, tx = cx + Math.cos(a) * w * 0.44, ty = h * 0.66 + Math.sin(a) * h * 0.27;
          return <Glyph key={i} t={sym(`e${i}`)} x={lerp(random(`ex${i}`) * w, tx, ease)} y={lerp(random(`ey${i}`) * h, ty, ease)}
            s={u * 0.035} o={0.5} rot={(1 - ease) * 180} />;
        })}
        <Orb x={cx} y={h * 0.28} size={u * 0.22} glow={0.9} mood="happy" hue={210} look={[0, 0.2]} />
      </SvgFull>
      <div style={{position: 'absolute', left: '12%', right: '12%', top: h * 0.5, textAlign: 'center', fontFamily: 'system-ui,sans-serif',
        fontWeight: 800, fontSize: u * 0.06, lineHeight: 1.25, color: '#fff', textShadow: '0 0 24px rgba(80,160,255,0.8)'}}>
        {words.map((wd, i) => (
          <span key={i} style={{opacity: interpolate(f - D * 0.3 - i * 6, [0, 10], [0, 1], C), marginRight: '0.28em', display: 'inline-block',
            color: wd.startsWith('smarter') ? '#7fe3ff' : wd.startsWith('overwhelm') ? '#ffb36b' : '#fff'}}>{wd}</span>
        ))}
      </div>
    </AbsoluteFill>
  );
};

/* ---------- WRAPPER: zoom, transition flash, caption, label ---------- */
const Captions: React.FC<{lines: string[]}> = ({lines}) => {
  const f = useCurrentFrame();
  const {D, w, h, u, wide} = useGeo();
  const seg = D / lines.length, i = Math.min(lines.length - 1, Math.floor(f / seg)), lf = f - i * seg;
  return <div style={{position: 'absolute', left: '7%', right: '7%', bottom: h * (wide ? 0.06 : 0.11), textAlign: 'center', color: '#fff',
    fontFamily: 'system-ui,sans-serif', fontWeight: 700, fontSize: u * (wide ? 0.04 : 0.046), lineHeight: 1.25,
    textShadow: '0 2px 12px #000, 0 0 4px #000', opacity: interpolate(lf, [0, 6, seg - 6, seg], [0, 1, 1, 0], C)}}>{lines[i]}</div>;
};

export const SceneView: React.FC<P> = ({def}) => {
  const f = useCurrentFrame();
  const {D, u, h} = useGeo();
  const zoom = interpolate(f, [0, 10], [1.14, 1], C) * interpolate(f, [0, D], [1, 1.07], C);
  const Comp = {hook: Hook, absorb: Absorb, predict: Predict, slowtime: SlowTime, overload: Overload, limit: Limit, ending: End}[def.kind];
  const showLabel = def.topic && def.kind !== 'limit' && def.kind !== 'ending';
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{transform: `scale(${zoom})`}}><Comp def={def} /></AbsoluteFill>
      {showLabel && <Banner text={def.topic} />}
      {def.kind !== 'ending' && <Captions lines={def.lines} />}
      <AbsoluteFill style={{background: '#9fd4ff', opacity: interpolate(f, [0, 6], [0.7, 0], C)}} />
    </AbsoluteFill>
  );
};

import React from 'react';
import {random, useCurrentFrame} from 'remotion';

export type Mood = 'calm' | 'curious' | 'focused' | 'shocked' | 'strained' | 'happy';
type Mouth = 'smile' | 'o' | 'flat' | 'wave' | 'big';
const MOODS: Record<Mood, {hue: number; squint: number; pupil: number; mouth: Mouth}> = {
  calm:     {hue: 210, squint: 0,    pupil: 1,    mouth: 'smile'},
  curious:  {hue: 200, squint: 0,    pupil: 1.15, mouth: 'smile'},
  focused:  {hue: 185, squint: 0.2,  pupil: 0.9,  mouth: 'flat'},
  shocked:  {hue: 50,  squint: -0.1, pupil: 0.55, mouth: 'o'},
  strained: {hue: 12,  squint: 0.35, pupil: 0.7,  mouth: 'wave'},
  happy:    {hue: 165, squint: 0.1,  pupil: 1.1,  mouth: 'big'},
};

const poly = (r: number, n: number, rot: number) =>
  Array.from({length: n}, (_, i) =>
    `${r * Math.cos(rot + (i * 2 * Math.PI) / n)},${r * Math.sin(rot + (i * 2 * Math.PI) / n)}`).join(' ');

/** The mascot. Render inside an <svg>. size = diameter in px. */
export const Orb: React.FC<{
  x: number; y: number; size: number; glow?: number; mood?: Mood; hue?: number;
  look?: [number, number]; jitter?: number; spin?: number;
}> = ({x, y, size, glow = 0.8, mood = 'calm', hue, look = [0, 0], jitter = 0, spin = 1}) => {
  const f = useCurrentFrame();
  const m = MOODS[mood];
  const h = hue ?? m.hue;
  const r = (size / 2) * (1 + Math.sin(f / 9) * 0.03 * (1 + glow));
  const bob = Math.sin(f / 18) * size * 0.06;
  const jx = jitter * (random(`jx${f}`) - 0.5) * size * 0.3;
  const jy = jitter * (random(`jy${f}`) - 0.5) * size * 0.3;
  const bp = f % 90;
  const blink = bp < 5 ? Math.max(0.1, Math.abs((bp - 2.5) / 2.5)) : 1;
  const eyeRy = r * 0.3 * blink * (1 - m.squint);
  const eyeRx = r * 0.24;
  const [lx, ly] = look;
  const mouthY = r * 0.4;
  return (
    <g transform={`translate(${x + jx},${y + bob + jy})`}>
      <defs>
        <radialGradient id="orbHalo">
          <stop offset="0" stopColor={`hsl(${h} 100% 60%)`} stopOpacity={Math.min(0.7, 0.45 * glow)} />
          <stop offset="1" stopColor={`hsl(${h} 100% 60%)`} stopOpacity={0} />
        </radialGradient>
        <radialGradient id="orbBody" cx="35%" cy="30%" r="80%">
          <stop offset="0" stopColor={`hsl(${h} 100% ${70 + glow * 12}%)`} />
          <stop offset="0.55" stopColor={`hsl(${h} 95% 55%)`} />
          <stop offset="1" stopColor={`hsl(${h} 90% 33%)`} />
        </radialGradient>
      </defs>
      <circle r={r * (1.7 + glow * 0.9)} fill="url(#orbHalo)" />
      {Array.from({length: 8}, (_, i) => {
        const a = f * spin * (0.03 + i * 0.006) + (i * 2 * Math.PI) / 8;
        const rad = r * (1.5 + 0.25 * (i % 3));
        return (
          <g key={i} transform={`translate(${Math.cos(a) * rad},${Math.sin(a) * rad * 0.8}) rotate(${f * spin * 3 + i * 40})`}>
            <polygon points={poly(r * 0.1, [3, 4, 4][i % 3], i % 3 === 2 ? Math.PI / 4 : 0)}
              fill={`hsl(${h} 100% 78%)`} opacity={0.85} />
          </g>
        );
      })}
      <circle r={r} fill="url(#orbBody)" />
      {[-1, 1].map((s) => (
        <g key={s} transform={`translate(${s * r * 0.34},${-r * 0.08})`}>
          <ellipse rx={eyeRx} ry={Math.max(1, eyeRy)} fill="#fff" />
          <circle cx={lx * eyeRx * 0.45} cy={ly * eyeRy * 0.4} r={eyeRx * 0.5 * m.pupil * blink} fill="#06122b" />
          <circle cx={lx * eyeRx * 0.45 - eyeRx * 0.15} cy={ly * eyeRy * 0.4 - eyeRy * 0.2} r={eyeRx * 0.14} fill="#fff" />
        </g>
      ))}
      {m.mouth === 'o' && <ellipse cy={mouthY} rx={r * 0.07} ry={r * 0.1} fill="#06122b" />}
      {m.mouth === 'smile' && <path d={`M ${-r * 0.13} ${mouthY} Q 0 ${mouthY + r * 0.12} ${r * 0.13} ${mouthY}`} stroke="#06122b" strokeWidth={r * 0.04} fill="none" strokeLinecap="round" />}
      {m.mouth === 'big' && <path d={`M ${-r * 0.2} ${mouthY - r * 0.02} Q 0 ${mouthY + r * 0.22} ${r * 0.2} ${mouthY - r * 0.02} Z`} fill="#06122b" />}
      {m.mouth === 'flat' && <line x1={-r * 0.1} x2={r * 0.1} y1={mouthY} y2={mouthY} stroke="#06122b" strokeWidth={r * 0.04} strokeLinecap="round" />}
      {m.mouth === 'wave' && <path d={`M ${-r * 0.16} ${mouthY} q ${r * 0.04} ${-r * 0.08} ${r * 0.08} 0 t ${r * 0.08} 0 t ${r * 0.08} 0 t ${r * 0.08} 0`} stroke="#06122b" strokeWidth={r * 0.04} fill="none" strokeLinecap="round" />}
    </g>
  );
};

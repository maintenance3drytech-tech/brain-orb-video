import React from 'react';
import {AbsoluteFill, random, useCurrentFrame, useVideoConfig} from 'remotion';

export const SYMBOLS = ['∑','π','∫','√','∞','Δ','λ','≈','∂','θ','0','1','7','Ω','≠','⊕','x²','Φ'];

export const Backdrop: React.FC<{speed?: number; count?: number}> = ({speed = 1, count = 24}) => {
  const f = useCurrentFrame();
  const {width: w, height: h} = useVideoConfig();
  const u = Math.min(w, h);
  return (
    <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 42%, #0b1438 0%, #04060f 72%)'}}>
      <svg width={w} height={h}>
        {Array.from({length: count}, (_, i) => {
          const sp = (0.3 + random(`bs${i}`) * 0.9) * speed;
          const y = (((random(`by${i}`) * h - f * sp * 1.2) % h) + h) % h;
          const x = random(`bx${i}`) * w + Math.sin(f / 50 + i) * 12;
          return (
            <text key={i} x={x} y={y} fontSize={u * (0.025 + random(`bz${i}`) * 0.04)}
              fill="#5aa8ff" opacity={0.08 + random(`bo${i}`) * 0.18} fontFamily="Georgia, serif">
              {SYMBOLS[Math.floor(random(`bt${i}`) * SYMBOLS.length)]}
            </text>
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};

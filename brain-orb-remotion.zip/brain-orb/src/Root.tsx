import React from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {FPS, totalFrames} from './scripts';

export const Root: React.FC = () => (
  <>
    <Composition id="BrainShort" component={Video} durationInFrames={totalFrames('short')}
      fps={FPS} width={1080} height={1920} defaultProps={{script: 'short' as const}} />
    <Composition id="BrainLong" component={Video} durationInFrames={totalFrames('long')}
      fps={FPS} width={1920} height={1080} defaultProps={{script: 'long' as const}} />
  </>
);

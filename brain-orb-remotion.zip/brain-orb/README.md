# Brain Orb — Remotion project

Two compositions sharing one mascot (`src/Orb.tsx`) and one visual system:
- `BrainShort` — 1080×1920 (9:16), 55 s
- `BrainLong` — 1920×1080 (16:9), 6:03

**Status: code only. No video file has been rendered yet.** Render it with the steps below.

## Render
```bash
npm install            # needs Node 18+
npm run dev            # live preview in Remotion Studio
npm run render:short   # -> out/brain-short-9x16.mp4
npm run render:long    # -> out/brain-long-16x9.mp4
```
If `npm install` complains about version mismatch, run `npx remotion upgrade`.

## Edit
- **Narration, timing, SFX cues, scene order:** `src/scripts.json` (single source of truth). `dur` is seconds per scene; narration lines are spread evenly across a scene. Run `npm run scripts:md` to refresh `SCRIPTS.md`.
- **Scenes:** `src/Scenes.tsx` (Hook, Absorb, Predict, SlowTime, Overload, Limit, End). `level` and `topic` in the JSON change density and which Limit panel shows.
- **Mascot moods:** `src/Orb.tsx` (`calm | curious | focused | shocked | strained | happy`).

## Audio (optional, free/open tools)
1. Set `USE_AUDIO = true` in `src/scripts.ts`.
2. Narration: generate one file per scene named `public/voice/short-1.mp3 … short-7.mp3` and `long-1.mp3 … long-10.mp3`. Open-source TTS: Piper or Kokoro (or record yourself).
3. SFX: put files in `public/sfx/` named after cues: `lowhum riser boom whoosh sparkle chime tick slowmo glitch buzz error drain heartbeat calm-pad`. Free sources: Freesound (CC0 filter), Pixabay SFX. Check each license.
4. Music: `public/music/short-bgm.mp3`, `long-bgm.mp3`. Suggestions: short = driving electronic, ~120 BPM, builds then drops to a calm pad for the ending. Long = ambient synth pad, slow build through overload, resolving to calm in the last scene. Use CC0 or properly credited tracks.
Re-run `npm run dev` to check sync, then adjust `dur`/cue times.

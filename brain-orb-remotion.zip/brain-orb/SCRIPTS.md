# Scripts

_Generated from src/scripts.json — edit that file, then run `npm run scripts:md`._


## What If Your Brain Used 100% of Its Processing Power? (Short, 9:16)
Runtime: 55s (0:55) · Music: short-bgm.mp3


### Scene 1 — HOOK  [0s–6s]

**Visual:** Orb floats in darkness; thousands of symbols pop in around it; eyes go wide.

**Narration:**
> What if your brain could process information a thousand times faster?

**SFX:** lowhum @0.0s, riser @2.0s, boom @5.2s


### Scene 2 — ABSORB  [6s–14s]

**Visual:** Symbols spiral into the orb; it swells and brightens.

**Narration:**
> It would absorb patterns in seconds.
> Not magic. Just speed.

**SFX:** whoosh @0.0s, sparkle @1.0s, chime @6.0s


### Scene 3 — PREDICT  [14s–22s]

**Visual:** Polygons drift in on curves; dotted lines show the orb's predicted paths.

**Narration:**
> Moving things? It would calculate their paths before they arrive.

**SFX:** whoosh @0.0s, tick @3.0s


### Scene 4 — SLOWTIME  [22s–30s]

**Visual:** World clock crawls while the orb's ring sweeps rapidly. Banner: FICTIONAL VISUALIZATION.

**Narration:**
> To the orb, the world feels slow.
> That's fiction. Time itself hasn't changed.

**SFX:** slowmo @0.0s, tick @4.0s


### Scene 5 — OVERLOAD  [30s–39s]

**Visual:** Symbols, sound waves, flying shapes flood the screen; orb glow flickers red.

**Narration:**
> But more input means more noise.
> Millions of signals. All at once.

**SFX:** riser @0.0s, glitch @4.0s, buzz @8.0s


### Scene 6 — LIMIT · all [39s–47s]

**Visual:** Three quick panels: memory slots overflow, battery drains, unknown tiles stay '?'.

**Narration:**
> Speed isn't memory. It isn't knowledge.
> And it still runs on limited energy.

**SFX:** error @0.0s, drain @2.7s, error @5.4s


### Scene 7 — ENDING  [47s–55s]

**Visual:** Orb stabilises to calm blue; symbols form the closing question.

**Narration:**
> So... would more processing power make you smarter, or just overwhelm you?

**SFX:** calm-pad @0.0s, chime @2.5s


## What If Your Brain Used 100% of Its Processing Power? (Long, 16:9)
Runtime: 363s (6:03) · Music: long-bgm.mp3


### Scene 1 — HOOK  [0s–32s]

**Visual:** Orb in darkness; calculations flood in; orb gets 'upgraded'.

**Narration:**
> Right now, your brain is doing something remarkable. About eighty-six billion neurons are working together on roughly twenty watts of power.
> But what if that changed? What if your brain could process information a thousand times faster than it does today?
> Meet our orb. It's a stand-in for a brain-processing system. And in three, two, one... it just got a massive upgrade.
> Before we begin: this is a thought experiment. The orb is a metaphor, not a medical diagram.

**SFX:** lowhum @0s, riser @10s, boom @20s


### Scene 2 — ABSORB · LEARNING [32s–80s]

**Visual:** Dense stream of symbols spirals into the orb; it grows and turns happy.

**Narration:**
> First thing you'd notice: learning. The orb takes in symbols, patterns, and rules almost as fast as they appear.
> A new language? Grammar and vocabulary, sorted in minutes. Advanced math? Patterns that normally take months to see, spotted instantly.
> But notice what's being sped up: how quickly information is handled. The orb still has to receive that information first.
> And here's a myth worth clearing up. You don't use just ten percent of your brain. Brain imaging shows activity across virtually all of it, over the course of a day. The upgrade here is speed, not unlocking a hidden reserve.

**SFX:** whoosh @0s, sparkle @8s, chime @36s


### Scene 3 — PREDICT · PREDICTION [80s–118s]

**Visual:** Five shapes on curved paths; dotted predicted trajectories and ghost shapes.

**Narration:**
> Now things start moving. Shapes drift toward the orb along curved paths.
> A faster processor can take in more of each movement and work out where it's heading. See the dotted lines? Those are the orb's predictions, drawn before the shapes get there.
> Real brains already do a small version of this. When you catch a ball, your brain is predicting where it will be, not where it is right now.
> With a thousand times more speed, the orb could run that prediction again and again, correcting itself every moment.

**SFX:** whoosh @0s, tick @12s, chime @28s


### Scene 4 — PREDICT · PATTERN SWARM [118s–150s]

**Visual:** Nine shapes, tangled paths; orb still tracks them, then shows limits of prediction.

**Narration:**
> Let's raise the difficulty. Many shapes now, all moving on different rhythms, crossing each other's paths.
> For a normal system, that's chaos. For the orb, it's a pattern. Every path is a rule, and rules can be computed.
> But watch closely. Prediction only works when there's a pattern to find. If something moves at random, even a super-fast orb can only guess.
> Speed helps with complicated. It doesn't help with truly unpredictable.

**SFX:** riser @0s, tick @14s, error @26s


### Scene 5 — SLOWTIME  [150s–195s]

**Visual:** Slow world clock and drifting shapes vs. rapid sweep ring and flickering equations. Banner: FICTIONAL VISUALIZATION.

**Narration:**
> Now for the strangest effect. To the orb, everything outside seems to slow down.
> Important: this is a fictional visualization. Time itself isn't slowing. The clocks outside tick at exactly the same rate.
> What changes is how much the orb can think about between ticks. Imagine fitting a thousand thoughts into the space where you'd normally have one.
> Real brains give us a hint of this. In frightening moments, time seems to stretch. But experiments suggest that's mostly memory: the brain records more detail, so the moment feels longer afterward. It isn't actually seeing faster.

**SFX:** slowmo @0s, tick @14s, heartbeat @30s


### Scene 6 — OVERLOAD  [195s–243s]

**Visual:** Symbol flood, sound-wave ribbons, flying shapes; orb shifts to red, jitters, flickers.

**Narration:**
> Then comes the problem. Faster processing doesn't shield you from input. It lets more in.
> Every sound, every flicker, every tiny movement now demands attention. Millions of symbols. Waves of sound. Moving objects from every direction.
> Real brains rely on filtering. Attention is a bottleneck on purpose, so the important signal doesn't drown in noise.
> Remove the filter, speed up the engine, and the orb's glow begins to flicker. Fast isn't the same as focused.
> Too many signals at once, and even a brilliant processor starts to fall apart.

**SFX:** riser @0s, glitch @20s, buzz @40s


### Scene 7 — LIMIT · memory [243s–273s]

**Visual:** Four memory slots fill; extra symbols bounce off with a red X.

**Narration:**
> So the orb steps back, and finds its first limit: memory.
> Thinking faster doesn't create more storage. Human working memory holds only about four chunks of information at once.
> A faster brain could shuffle those four slots more quickly, but it would still have four slots. Extra information just bounces off.

**SFX:** calm-pad @0s, error @12s


### Scene 8 — LIMIT · energy [273s–303s]

**Visual:** Battery drains from green to red while the orb strains.

**Narration:**
> The second limit: energy. Your brain is about two percent of your body weight, yet it burns roughly twenty percent of your energy.
> Running a thousand times faster would demand far more fuel and produce far more heat. Neurons also can't fire infinitely fast. Their signals have physical speed limits.
> No upgrade comes free. Faster means hungrier.

**SFX:** lowhum @0s, drain @10s


### Scene 9 — LIMIT · knowledge [303s–331s]

**Visual:** A scanner sweeps a tile grid; only three tiles light up, the rest stay '?'.

**Narration:**
> The third limit: knowledge. A fast mind still can't compute facts it never learned.
> It can't know tomorrow's weather, or a stranger's name, just by thinking harder. Processing power works on information. It doesn't create it.
> So: no perfect knowledge, no unlimited memory, no infinite energy.

**SFX:** tick @0s, error @22s


### Scene 10 — ENDING  [331s–363s]

**Visual:** Orb settles to calm blue; symbols gather and spell the question word by word.

**Narration:**
> Slowly, the orb figures it out. It filters the noise. It focuses on what matters. And the glow settles back into a steady blue.
> The real superpower was never speed alone. It was knowing what to pay attention to.
> So here's the question to leave you with.
> Would more processing power make you smarter, or just overwhelm you?

**SFX:** calm-pad @0s, chime @20s

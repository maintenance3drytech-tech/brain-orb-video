import json, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
d = json.load(open(root/'src/scripts.json'))
out = ['# Scripts\n', '_Generated from src/scripts.json — edit that file, then run `npm run scripts:md`._\n']
for k in ('short','long'):
    s = d[k]; total = sum(x['dur'] for x in s['scenes'])
    out.append(f"\n## {s['title']}\nRuntime: {total}s ({total//60}:{total%60:02d}) · Music: {s['music']}\n")
    t = 0
    for i, sc in enumerate(s['scenes'], 1):
        out.append(f"\n### Scene {i} — {sc['kind'].upper()} {('· '+sc['topic']) if sc['topic'] else ''} [{t}s–{t+sc['dur']}s]\n")
        out.append(f"**Visual:** {sc['visual']}\n")
        out.append("**Narration:**\n" + "\n".join(f"> {l}" for l in sc['lines']) + "\n")
        out.append("**SFX:** " + ", ".join(f"{x['cue']} @{x['t']}s" for x in sc['sfx']) + "\n")
        t += sc['dur']
(root/'SCRIPTS.md').write_text("\n".join(out))
